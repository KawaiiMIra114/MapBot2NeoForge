﻿---
id: unity-reverse-engineering
name: Unity逆向工程知识库
description: DLL分析技术要点
---

# Unity逆向知识库

## DLL类型
- IL2CPP：GameAssembly.dll + global-metadata.dat
- Mono：Assembly-CSharp.dll 或 a*.dll

## AES规范
| 类型 | 密钥 | IV |
|------|------|-----|
| AES-128 | 16字节 | 16字节 |
| AES-256 | 32字节 | 16字节 |

## 搜索词
- AES：aeskey, aesiv, encrypt, Rijndael
- Packet：packet, protocol, Serialize

## dnSpy
- Ctrl+Shift+K：搜索字符串
- Ctrl+T：搜索类型
- Analyze：追踪调用链

## 注意
- amdaemon.dll是系统进程，直接跳过
