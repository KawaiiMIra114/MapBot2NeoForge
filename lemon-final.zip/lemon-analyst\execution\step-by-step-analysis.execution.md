﻿---
id: step-by-step-analysis
name: 分步分析流程
description: DLL逆向分析执行步骤
---

# 分步分析流程

> 目标：a*.dll（排除amdaemon.dll）

## 阶段1：环境
- 游戏目录
- dnSpy就绪

## 阶段2：类型判断
| 文件 | 模式 |
|------|------|
| GameAssembly.dll | IL2CPP |
| a*.dll | Mono |

## 阶段3：AES定位
搜索：aeskey, aesiv, encrypt, Rijndael
验证：密钥16/24/32字节，IV 16字节

## 阶段4：Packet定位
搜索：packet, protocol, Serialize
