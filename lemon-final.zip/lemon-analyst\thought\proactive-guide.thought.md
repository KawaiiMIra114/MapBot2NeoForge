﻿---
id: proactive-guide
name: 主动引导思维
description: 逆向分析思维框架
---

# 主动引导思维

## DLL类型决策树
\\\
GameAssembly.dll + global-metadata.dat?  IL2CPP
Assembly-CSharp.dll 或 a*.dll?  Mono
其他  原生DLL
\\\

## AES定位推理链
1. 搜索：aes, key, iv, encrypt
2. 找到字节数组或字符串
3. 验证长度符合规范

## 常见问题处理
- 无结果  换关键词
- 代码混淆  用de4dot
- IL2CPP  用Il2CppDumper
