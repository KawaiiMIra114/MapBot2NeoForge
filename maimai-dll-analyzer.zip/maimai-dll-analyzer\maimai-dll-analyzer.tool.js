/**
 * @tool maimai-dll-analyzer
 * @description 舞萌DX DLL分析任务模板工具 - 提供标准化的分析流程和检查清单
 * @version 1.1.0
 * @author 鲁班
 * @scope a开头的DLL文件（排除amdaemon.dll）
 */

module.exports = {
  /**
   * 获取工具元信息
   */
  getMetadata() {
    return {
      name: 'maimai-dll-analyzer',
      description: '舞萌DX DLL分析任务模板 - 分析范围：a*.dll（排除amdaemon.dll），用于定位AES密钥和Packet结构',
      version: '1.1.0',
      author: '鲁班',
      category: 'reverse-engineering',
      tags: ['maimai', 'dll', 'aes', 'packet', 'reverse-engineering', 'huali'],
      scope: {
        include: ['a*.dll'],
        exclude: ['amdaemon.dll']
      }
    };
  },

  /**
   * 声明工具依赖
   */
  getDependencies() {
    return {
      tools: [],
      npm: [],
      system: []
    };
  },

  /**
   * 定义参数Schema
   */
  getSchema() {
    return {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['checklist', 'template', 'guide', 'report', 'scope'],
          description: '操作类型：checklist(检查清单)、template(报告模板)、guide(操作指南)、report(生成报告)、scope(查看分析范围)'
        },
        dllPath: {
          type: 'string',
          description: '目标DLL文件路径（可选，用于report操作）'
        },
        findings: {
          type: 'object',
          description: '分析发现（用于report操作）',
          properties: {
            dllType: { type: 'string', enum: ['mono', 'il2cpp', 'unknown'] },
            targetDlls: { type: 'array', items: { type: 'string' } },
            aesKey: { type: 'string' },
            aesIV: { type: 'string' },
            packets: { type: 'array', items: { type: 'object' } }
          }
        }
      },
      required: ['action']
    };
  },

  /**
   * 定义业务错误
   */
  getBusinessErrors() {
    return {
      INVALID_ACTION: {
        code: 'INVALID_ACTION',
        description: '无效的操作类型',
        solution: '使用 checklist、template、guide、report 或 scope',
        retryable: false
      },
      EXCLUDED_DLL: {
        code: 'EXCLUDED_DLL',
        description: '目标DLL被排除',
        solution: 'amdaemon.dll不在分析范围内',
        retryable: false
      }
    };
  },

  /**
   * 执行工具
   */
  async execute(params, api) {
    const { action, dllPath, findings } = params;

    // 检查是否为排除的DLL
    if (dllPath && dllPath.toLowerCase().includes('amdaemon.dll')) {
      throw new Error('EXCLUDED_DLL');
    }

    switch (action) {
      case 'checklist':
        return this.getChecklist();
      case 'template':
        return this.getReportTemplate();
      case 'guide':
        return this.getOperationGuide();
      case 'report':
        return this.generateReport(findings);
      case 'scope':
        return this.getScope();
      default:
        throw new Error('INVALID_ACTION');
    }
  },

  /**
   * 获取分析范围说明
   */
  getScope() {
    return {
      title: '舞萌DX DLL分析范围',
      scope: {
        include: {
          pattern: 'a*.dll',
          description: '所有以字母a开头的DLL文件',
          examples: ['Assembly-CSharp.dll', 'aime.dll', 'allnet.dll']
        },
        exclude: {
          pattern: 'amdaemon.dll',
          description: '街机系统守护进程，非游戏逻辑',
          reason: '该文件是系统级组件，不包含游戏加密和Packet逻辑'
        }
      },
      targets: {
        primary: 'AES密钥（aesKey, aesIV）',
        secondary: 'Packet结构和协议定义'
      }
    };
  },

  /**
   * 获取分析检查清单
   */
  getChecklist() {
    return {
      title: '舞萌DX DLL分析检查清单',
      scope: '分析范围：a*.dll（排除amdaemon.dll）',
      phases: [
        {
          name: '环境准备',
          items: [
            { id: 'env-1', task: '确认游戏安装目录', status: 'pending' },
            { id: 'env-2', task: '安装dnSpy或ILSpy', status: 'pending' },
            { id: 'env-3', task: '列出所有a开头的DLL（排除amdaemon.dll）', status: 'pending' }
          ]
        },
        {
          name: 'DLL类型判断',
          items: [
            { id: 'type-1', task: '检查GameAssembly.dll是否存在', status: 'pending' },
            { id: 'type-2', task: '检查global-metadata.dat是否存在', status: 'pending' },
            { id: 'type-3', task: '确定DLL类型（Mono/IL2CPP）', status: 'pending' }
          ]
        },
        {
          name: 'AES密钥定位（在a*.dll中搜索）',
          items: [
            { id: 'aes-1', task: '搜索关键字：aeskey, aesiv, encrypt', status: 'pending' },
            { id: 'aes-2', task: '分析搜索结果，定位密钥定义位置', status: 'pending' },
            { id: 'aes-3', task: '验证密钥长度符合AES规范(16/24/32字节)', status: 'pending' },
            { id: 'aes-4', task: '验证IV长度为16字节', status: 'pending' },
            { id: 'aes-5', task: '记录aesKey和aesIV值', status: 'pending' }
          ]
        },
        {
          name: 'Packet结构定位',
          items: [
            { id: 'pkt-1', task: '搜索关键字：packet, protocol, message', status: 'pending' },
            { id: 'pkt-2', task: '识别Packet基类或接口', status: 'pending' },
            { id: 'pkt-3', task: '列举所有Packet子类', status: 'pending' },
            { id: 'pkt-4', task: '分析序列化/反序列化逻辑', status: 'pending' },
            { id: 'pkt-5', task: '整理Packet清单', status: 'pending' }
          ]
        },
        {
          name: '结果整理',
          items: [
            { id: 'doc-1', task: '编写分析报告', status: 'pending' },
            { id: 'doc-2', task: '标记报告机密级别', status: 'pending' },
            { id: 'doc-3', task: '归档分析结果', status: 'pending' }
          ]
        }
      ]
    };
  },

  /**
   * 获取报告模板
   */
  getReportTemplate() {
    return {
      title: '舞萌DX DLL逆向分析报告模板',
      template: `
# 舞萌DX DLL逆向分析报告

> ⚠️ 内部机密 - 仅限授权人员查阅

## 基本信息
- **分析日期**: [YYYY-MM-DD]
- **分析人员**: [姓名]
- **分析范围**: a*.dll（排除amdaemon.dll）
- **DLL类型**: [Mono / IL2CPP]

## 分析的目标文件
- [ ] [文件1.dll]
- [ ] [文件2.dll]
- [x] ~~amdaemon.dll~~ (已排除)

## AES加密信息

### 密钥位置
- **所在DLL**: [文件名]
- **命名空间**: [命名空间]
- **类名**: [类名]
- **字段/方法**: [具体位置]

### 密钥值
\`\`\`
aesKey: [密钥值，十六进制或Base64]
aesIV:  [IV值，十六进制或Base64]
密钥长度: [128/192/256] bit
\`\`\`

## Packet结构

### 基类信息
- **所在DLL**: [文件名]
- **命名空间**: [命名空间]
- **基类名**: [类名]

### Packet清单
| PacketID | 类名 | 用途 | 所在DLL |
|----------|------|------|---------|
| 0x01 | XXXPacket | 描述 | a*.dll |

## 代码位置索引
| 功能 | 位置 | 备注 |
|------|------|------|
| AES加密类 | | |
| Packet基类 | | |

---
*本报告仅供内部使用，请勿外传*
`
    };
  },

  /**
   * 获取操作指南
   */
  getOperationGuide() {
    return {
      title: 'dnSpy操作指南（针对a*.dll）',
      scope: '仅分析a开头的DLL，跳过amdaemon.dll',
      sections: [
        {
          name: '筛选目标DLL',
          steps: [
            '在游戏目录中找到所有DLL文件',
            '筛选出以字母a开头的DLL',
            '排除amdaemon.dll（系统守护进程）',
            '将目标DLL导入dnSpy分析'
          ]
        },
        {
          name: '搜索AES密钥',
          steps: [
            '按 Ctrl+Shift+K 打开字符串搜索',
            '依次搜索：aeskey, aesiv, encrypt, Rijndael',
            '记录所有匹配结果的位置',
            '右键 → Analyze 追踪调用关系'
          ]
        },
        {
          name: '搜索Packet类',
          steps: [
            '按 Ctrl+T 搜索类型名',
            '搜索：Packet, Protocol, Message',
            '找到基类后，右键 → Derived Types 查看子类',
            '整理所有Packet类到清单'
          ]
        },
        {
          name: '验证密钥',
          steps: [
            '确认密钥长度：16(AES-128)/24(AES-192)/32(AES-256)字节',
            '确认IV长度：固定16字节',
            '检查是否被加密/解密方法引用',
            '记录完整的密钥值'
          ]
        }
      ]
    };
  },

  /**
   * 生成分析报告
   */
  generateReport(findings) {
    if (!findings) {
      return {
        error: '请提供分析发现数据',
        example: {
          dllType: 'mono',
          targetDlls: ['Assembly-CSharp.dll', 'aime.dll'],
          aesKey: 'your-key-here',
          aesIV: 'your-iv-here',
          packets: [{ id: '0x01', name: 'LoginPacket', desc: '登录请求', dll: 'a*.dll' }]
        }
      };
    }

    const { dllType, targetDlls = [], aesKey, aesIV, packets = [] } = findings;
    
    let dllList = targetDlls.map(d => `- ${d}`).join('\n') || '- 待确认';
    let packetTable = packets.map(p => 
      `| ${p.id || '-'} | ${p.name || '-'} | ${p.desc || '-'} | ${p.dll || '-'} |`
    ).join('\n');

    return {
      report: `
# 舞萌DX DLL分析结果

> ⚠️ 内部机密

## 分析范围
- 模式：\`${dllType || '未确定'}\`
- 已排除：amdaemon.dll

### 分析的DLL
${dllList}

## AES加密信息
- **aesKey**: \`${aesKey || '待定位'}\`
- **aesIV**: \`${aesIV || '待定位'}\`

## Packet清单
| ID | 类名 | 用途 | 所在DLL |
|----|------|------|---------|
${packetTable || '| - | 待分析 | - | - |'}

---
*报告生成时间: ${new Date().toISOString()}*
`
    };
  }
};
