---
id: unity-reverse-engineering
name: Unity逆向工程知识库
description: Unity游戏DLL分析的专业知识、技术要点和常见问题
---

# Unity逆向工程知识库

> 分析范围：a开头的DLL文件（排除amdaemon.dll）

## DLL类型判断

### IL2CPP模式特征
- 存在 `GameAssembly.dll`（包含所有C#编译后的原生代码）
- 存在 `global-metadata.dat`（包含类型元数据）
- C#代码已编译为原生代码，无法直接反编译为源码
- 需要使用 Il2CppDumper 提取结构信息

### Mono模式特征
- 存在 `Assembly-CSharp.dll` 或 `a*.dll` 托管DLL
- DLL可直接用dnSpy/ILSpy打开并查看C#源码
- 代码结构清晰，类名和方法名可读

## AES密钥定位策略

### 关键搜索词（优先级排序）
```
1. aeskey, aesKey, AesKey, AESKEY
2. aesiv, aesIV, AesIV, AESIV
3. encrypt, Encrypt, decrypt, Decrypt
4. Rijndael, AesCryptoServiceProvider
5. cipher, Cipher, secret, Secret
```

### 常见代码模式
```csharp
// 模式1：静态字节数组（最常见）
private static readonly byte[] aesKey = { 0x01, 0x02, ... };
private static readonly byte[] aesIV = { 0x11, 0x12, ... };

// 模式2：字符串常量
private const string KEY = "your-aes-key-here";

// 模式3：配置读取
var key = Config.GetValue("EncryptionKey");

// 模式4：Base64编码
byte[] key = Convert.FromBase64String("base64-string");
```

### AES规范速查
| 类型 | 密钥长度 | IV长度 |
|------|----------|--------|
| AES-128 | 16字节 (128位) | 16字节 |
| AES-192 | 24字节 (192位) | 16字节 |
| AES-256 | 32字节 (256位) | 16字节 |

## Packet相关代码定位

### 关键搜索词
```
packet, Packet, PACKET
message, Message, NetworkMessage
protocol, Protocol
send, Send, receive, Receive
serialize, Serialize, deserialize, Deserialize
IPacket, BasePacket, PacketBase
```

### 常见代码结构
```csharp
public abstract class BasePacket
{
    public int PacketId { get; set; }
    public abstract byte[] Serialize();
    public abstract void Deserialize(byte[] data);
}

public class NetworkManager
{
    public void SendPacket(BasePacket packet) { ... }
    public void OnPacketReceived(byte[] data) { ... }
}
```

## 🚨 常见问题与解决方案

### 问题1：搜索无结果
**原因**：关键字拼写变体、混淆、非标准命名
**解决**：
- 尝试更通用的词如 "key"、"secret"
- 检查是否有命名空间前缀
- 使用正则搜索

### 问题2：代码被混淆
**特征**：类名方法名是随机字符如 `a1b2c3`
**解决**：
- 使用de4dot反混淆工具
- 通过字符串常量定位功能
- 追踪System.Security.Cryptography调用

### 问题3：密钥动态生成
**特征**：找不到硬编码密钥，只有生成逻辑
**解决**：
- 分析生成算法，找到种子或输入
- 运行时调试获取实际值
- 检查是否基于设备ID等

### 问题4：amdaemon.dll干扰
**说明**：这是街机系统守护进程，非游戏逻辑
**处理**：直接排除，专注分析其他a开头的DLL

## dnSpy操作速查

| 操作 | 快捷键 | 用途 |
|------|--------|------|
| 搜索字符串 | Ctrl+Shift+K | 查找硬编码的密钥 |
| 搜索类型 | Ctrl+T | 快速定位Packet类 |
| 分析引用 | 右键→Analyze | 追踪调用链 |
| 导出项目 | File→Export | 获取源码副本 |

## 舞萌DX特定知识

### 已知目标文件
- 重点关注：`a*.dll`（排除amdaemon.dll）
- 可能包含：加密模块、网络通信、游戏逻辑

### 分析建议
1. 先确定游戏版本和区域（国服/日服差异）
2. 华立科技作为国服运营商可能有定制修改
3. 关注与服务器通信相关的加密逻辑
