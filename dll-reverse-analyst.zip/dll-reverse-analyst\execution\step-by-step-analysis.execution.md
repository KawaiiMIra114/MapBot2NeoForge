---
id: step-by-step-analysis
name: 分步分析执行流程
description: 带错误处理的DLL逆向分析标准化执行步骤
---

# 分步分析执行流程

> 目标范围：a开头的DLL文件（排除amdaemon.dll）

## 第一阶段：环境准备

### 步骤1.1 - 确认目标文件
```
请提供以下信息：
1. 游戏安装目录的完整路径
2. 列出目录中所有a开头的DLL（排除amdaemon.dll）
```

**验证标准**: 用户提供了有效路径和目标DLL列表

**⚠️ 可能失败**:
- 路径不存在 → 请用户重新确认安装位置
- 没有a开头的DLL → 检查子目录或确认游戏版本

### 步骤1.2 - 确认工具就绪
- [ ] dnSpy 已安装（推荐 v6.1.8+）
- [ ] 或 ILSpy 已安装
- [ ] （IL2CPP时需要）Il2CppDumper 已准备

**⚠️ 可能失败**:
- dnSpy打不开 → 检查.NET Framework版本
- 下载失败 → 提供备用下载链接

---

## 第二阶段：DLL类型判断

### 步骤2.1 - 检查游戏目录
在游戏目录中查找以下文件：

| 文件名 | 存在？ | 含义 |
|--------|--------|------|
| GameAssembly.dll | □ | IL2CPP模式 |
| global-metadata.dat | □ | IL2CPP模式 |
| a*.dll（非amdaemon.dll） | □ | 分析目标 |

### 步骤2.2 - 确定分析策略

**✅ 如果是Mono模式：**
→ 直接用dnSpy打开目标DLL
→ 进入第三阶段

**⚠️ 如果是IL2CPP模式：**
→ 使用Il2CppDumper提取元数据
→ 使用IDA分析GameAssembly.dll
→ 这是高级场景，需要更多时间

**验证标准**: 成功用dnSpy打开DLL并看到类结构

**⚠️ 可能失败**:
- DLL打不开 → 可能是原生DLL，需用IDA
- 代码被混淆 → 需要先反混淆

---

## 第三阶段：AES密钥定位

### 步骤3.1 - 关键字搜索
在dnSpy中使用 `Ctrl+Shift+K` 搜索：
1. `aeskey` / `aesKey` / `AesKey`
2. `aesiv` / `aesIV` / `AesIV`
3. `encrypt` / `Encrypt`
4. `Rijndael` / `AesCryptoServiceProvider`

**验证标准**: 至少匹配到1个相关结果

**⚠️ 可能失败**:
- 无搜索结果 → 尝试搜索 "key"、"secret"、"cipher"
- 太多结果 → 缩小范围，优先看静态字段

### 步骤3.2 - 结果分析
对于每个搜索结果：
- 记录所在类名和方法名
- 检查是否为静态字段或常量
- 右键 → Analyze → 查看 "Used By"

### 步骤3.3 - 密钥验证
| 检查项 | 期望值 | 实际值 |
|--------|--------|--------|
| aesKey长度 | 16/24/32字节 | _____ |
| aesIV长度 | 16字节 | _____ |
| 被加密函数引用 | 是 | _____ |

**⚠️ 可能失败**:
- 长度不符合规范 → 可能不是AES，检查其他算法
- 密钥被动态生成 → 需要分析生成算法

---

## 第四阶段：Packet代码定位

### 步骤4.1 - 搜索Packet相关
搜索关键字（在a*.dll范围内，排除amdaemon.dll）：
1. `packet` / `Packet`
2. `protocol` / `Protocol`
3. `Serialize` / `Deserialize`
4. `NetworkMessage` / `BasePacket`

**验证标准**: 找到Packet基类或接口定义

### 步骤4.2 - 识别数据包结构
- 找到继承关系（如 `class XXX : BasePacket`）
- 识别数据包ID字段
- 理解序列化/反序列化逻辑

### 步骤4.3 - 整理发现
创建Packet清单：
| PacketID | 类名 | 用途描述 | 所在DLL |
|----------|------|----------|---------|
| 0x01 | LoginPacket | 登录请求 | a*.dll |
| ... | ... | ... | ... |

**⚠️ 可能失败**:
- 找不到Packet类 → 尝试搜索 "message"、"command"
- 结构太复杂 → 先专注核心Packet

---

## 第五阶段：输出总结

### 输出模板
```markdown
# 舞萌DX逆向分析结果

## 分析范围
- 目标：a开头的DLL（排除amdaemon.dll）
- 分析的文件：[文件列表]
- DLL类型：[Mono/IL2CPP]

## AES加密信息
- 所在DLL：[文件名]
- 所在类：[命名空间.类名]
- aesKey: [值，十六进制或Base64]
- aesIV: [值，十六进制或Base64]
- 密钥长度：[位数] bit

## Packet结构
[Packet清单表格]

## 相关代码位置索引
| 功能 | 位置 | 备注 |
|------|------|------|
| AES加密类 | | |
| Packet基类 | | |
```
